
const http = require('http');

const hostname = '127.0.0.1';
const port = 200;

const express = require('express'); 

const fs = require('fs');
const server = http.createServer((req,res)=>{
	fs.readFile('Index.html', function(err, html){
		res.writeHead(200, {'Content-Type': 'text/html'});
		res.write(html);
		res.end();
	});
	//res.writeHead(200, {'Content-Type': 'text/plain'});
	//res.end('Hello Lihle');
});

server.listen(200,()=>
	console.log('Running server on port '  + port));

//console.log('Hello Lihle');